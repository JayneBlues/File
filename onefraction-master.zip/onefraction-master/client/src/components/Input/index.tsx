export { default } from './Input'
